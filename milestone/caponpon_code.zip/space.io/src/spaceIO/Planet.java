package spaceIO;

import java.util.Random;
import javafx.scene.image.Image;



public class Planet extends Sprite{
	private String name;
	private int score;
	private boolean alive;
	
//	private ArrayList<Bullet> bullets;
	public static Image planetImage;
//	private final static int PLANET_RADIUS = 40;

	public Planet(String name, int x, int y){
		super(x,y);
		this.name = name;
		this.score = 40;
		planetImage= new Image("assets/planet1.png", score, score,true,false);
		this.alive = true;
//		this.bullets = new ArrayList<Bullet>();
		this.loadImage(Planet.planetImage);
	}

	public boolean isAlive(){
		if(this.alive) return true;
		return false;
	} 
	public String getName(){
		return this.name;
	}

	public void die(){
    	this.alive = false;
    }

	//method that will get the bullets 'shot' by the ship
//	public ArrayList<Bullet> getBullets(){
//		return this.bullets;
//	}
	
	/*
	 * method called if spacebar is pressed. 
	 * Instantiate a new bullet and add it to the bullets arraylist of ship
	 */
//	public void shoot(){
//		int x = (int) (this.x + this.width+20);
//		int y = (int) (this.y + this.height/2);
//		this.bullets.add(new Bullet(x,y));
//    }
	
	/*
	 *method called if up/down/left/right arrow key is pressed.
	 *Change the x and y position of the ship if the current x,y position 
	 *is within the gamestage width and height.
	 */
	public void move() {
		if(this.x+this.dx <= GameStage.MAP_WIDTH-this.width && this.x+this.dx >=0 && this.y+this.dy <= GameStage.MAP_HEIGHT-this.width && this.y+this.dy >=0){
    		this.x += this.dx;
    		this.y += this.dy;
    	}
	}

	public int getSpeed() {
		return 120/score;
	}

}
