package spaceIO;

import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GameStage {
	public static final int WINDOW_HEIGHT = 800;
	public static final int WINDOW_WIDTH = 800;
	public static final int MAP_HEIGHT = 2400;
	public static final int MAP_WIDTH = 2400;
	private Scene scene;
	private Stage stage;
	private Canvas canvas;
	private Canvas scoreBoard;
	private VBox root;
	private ScrollPane scrollPane;
	private GraphicsContext gc;
	private GraphicsContext gcScore;
	private GameTimer gametimer;
	
	
	//the class constructor
	public GameStage() {
		this.root = new VBox();
		this.canvas = new Canvas(GameStage.MAP_WIDTH, GameStage.MAP_HEIGHT);
		this.scoreBoard = new Canvas(WINDOW_WIDTH, 50);
		this.scrollPane = new ScrollPane(canvas);
		this.gc = canvas.getGraphicsContext2D();
		this.gcScore = scoreBoard.getGraphicsContext2D();
		this.scene = new Scene(root, GameStage.WINDOW_WIDTH,GameStage.WINDOW_HEIGHT);
		gcScore.setFont(new Font("Helvetica Neue", 45));
		gcScore.fillText("Time: 0", 1, 40);

		//instantiate an animation timer
		this.gametimer = new GameTimer(this.gc, this.scene, this.scrollPane, this.gcScore);
	}

	//method to add the stage elements
	public void setStage(Stage stage) {
		this.stage = stage;
		
		//set stage elements here
		this.root.getChildren().addAll(scoreBoard, scrollPane);
		this.stage.setTitle("space.io");
		this.stage.setScene(this.scene);


		//invoke the start method of the animation timer

		this.gametimer.start();
		this.stage.show();
	}
	

	
}

