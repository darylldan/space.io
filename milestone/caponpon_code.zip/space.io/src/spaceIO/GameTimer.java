package spaceIO;

import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;

import java.util.concurrent.TimeUnit;

/*
 * The GameTimer is a subclass of the AnimationTimer class. It must override the handle method. 
 */
 
public class GameTimer extends AnimationTimer{

	private long intTime;

	private GraphicsContext gc;
	private GraphicsContext gcScore;
	private Scene theScene;
	private Planet myPlanet;
	private ScrollPane camera;
//	private ArrayList<Fish> fishes;
//	public static final int MAX_NUM_FISHES = 3;
	
	GameTimer(GraphicsContext gc, Scene theScene, ScrollPane scrollPane, GraphicsContext gcScore){
		this.gc = gc;
		this.gcScore = gcScore;
		this.theScene = theScene;
		this.myPlanet = new Planet("Going merry",GameStage.MAP_HEIGHT / 2,GameStage.MAP_WIDTH / 2);
		this.camera = scrollPane;
		camera.setHvalue((myPlanet.getX() / 2 - camera.getViewportBounds().getWidth() / 2) / (myPlanet.getX() - camera.getViewportBounds().getWidth()));
		camera.setVvalue((myPlanet.getY() / 2 - camera.getViewportBounds().getHeight() / 2) / (myPlanet.getY()- camera.getViewportBounds().getHeight()));
		intTime = System.nanoTime();

		//instantiate the ArrayList of Fish
//		this.fishes = new ArrayList<Fish>();
		//call the spawnFishes method
//		this.spawnFishes();
		//call method to handle mouse click event
		this.handleKeyPressEvent();
	}

	@Override
	public void handle(long currentNanoTime) {
		long currTime = TimeUnit.NANOSECONDS.toSeconds(currentNanoTime);
		long startTime = TimeUnit.NANOSECONDS.toSeconds(intTime);

		if (currTime - startTime >= 1) {
			intTime++;
			updateTime((int) (currTime - startTime));
		}

		gc.clearRect(0,0, GameStage.MAP_WIDTH, GameStage.MAP_HEIGHT);


		//call the methods to move the ship, bullets and fishes
		gc.drawImage(new Image("assets/bg-50.jpg"), 0, 0);
		this.myPlanet.move();
//		this.moveBullets();
//		this.moveFishes();
		
		//render the ship
		this.myPlanet.render(this.gc);


		//call the render fishes and render bullets methods
//		this.renderFishes();
//		this.renderBullets();
		   	
		//check collision of fishes ad ship
//		for(Fish f: this.fishes){
//			f.checkCollision(this.myShip);
//		}
//		
//		if(!this.myShip.isAlive())
//	        	this.stop();
	}

	private void updateTime(int startTime) {
		gcScore.clearRect(0,0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
		gcScore.fillText("Time: " + startTime, 1, 45);
	}

//	//method that will render/draw the fishes to the canvas
//	private void renderFishes() {
//		for (Fish f : this.fishes){
//			f.render(this.gc);
//		}
//	}

	//method that will render/draw the bullets to the canvas
//	private void renderBullets() {
//		for (Bullet b : this.myShip.getBullets()){
//	    	b.render(this.gc);
//		}
//	}
	
	//method that will spawn/instantiate three fishes at a random x,y location
//	private void spawnFishes(){
//		Random r = new Random();
//
//		for(int i=0;i<GameTimer.MAX_NUM_FISHES;i++){
//			int x = r.nextInt(200)+600;
//			int y = r.nextInt(GameStage.WINDOW_HEIGHT-50);
//			this.fishes.add(new Fish(x,y));
//			System.out.println("A fish has spawned.");
//		}
//
//	}
	
	//method that will listen and handle the key press events
	private void handleKeyPressEvent() {
		theScene.setOnKeyPressed(new EventHandler<KeyEvent>(){
			public void handle(KeyEvent e){
            	KeyCode code = e.getCode();
                moveMyShip(code);
			}
			
		});
		
		theScene.setOnKeyReleased(new EventHandler<KeyEvent>(){
		            public void handle(KeyEvent e){
		            	KeyCode code = e.getCode();
		                stopMyShip(code);
		            }
		        });
    }
	
	//method that will move the ship depending on the key pressed
	private void moveMyShip(KeyCode ke) {
		if(ke==KeyCode.W) {
			this.myPlanet.setDY(- 1 * myPlanet.getSpeed());
//			gc.translate(0, gc.getCanvas().getLayoutX() + (- 1 * myPlanet.getSpeed()));
			System.out.println("X POS: " + myPlanet.x + " Y POS: " + myPlanet.y);
		}

		if(ke==KeyCode.A) {
			this.myPlanet.setDX(- 1 * myPlanet.getSpeed());
//			gc.translate(gc.getCanvas().getLayoutX() + (- 1 * myPlanet.getSpeed()), 0);
			System.out.println("X POS: " + myPlanet.x + " Y POS: " + myPlanet.y);
		}

		if(ke==KeyCode.S) {
			this.myPlanet.setDY(myPlanet.getSpeed());
//			gc.translate(0, gc.getCanvas().getLayoutX() + myPlanet.getSpeed());
			System.out.println("X POS: " + myPlanet.x + " Y POS: " + myPlanet.y);


		}
		
		if(ke==KeyCode.D) {
			this.myPlanet.setDX(myPlanet.getSpeed());
//			gc.translate(gc.getCanvas().getLayoutX() +  myPlanet.getSpeed(), 0);
			System.out.println("X POS: " + myPlanet.x + " Y POS: " + myPlanet.y);

		}
		
//		if(ke==KeyCode.SPACE) this.myShip.shoot();
		
		System.out.println(ke+" key pressed.");
   	}



	//method that will stop the ship's movement; set the ship's DX and DY to 0
	private void stopMyShip(KeyCode ke){
		this.myPlanet.setDX(0);
		this.myPlanet.setDY(0);
	}
	
	//method that will move the bullets shot by a ship
//	private void moveBullets(){
//		//create a local arraylist of Bullets for the bullets 'shot' by the ship
//		ArrayList<Bullet> bList = this.myShip.getBullets();
//		/*
//		 * Loop through the bullet list and check whether a bullet is still visible.
//		 * If a bullet is visible, move the bullet, else, remove the bullet from the bullet array list.
//		 * */
//		for(int i = 0; i < bList.size(); i++){
//			Bullet b = bList.get(i);
//			if(b.isVisible())
//				b.move();
//			else bList.remove(i);
//		}
//	}
	
	//method that will move the fishes 
//	private void moveFishes(){
//		/*
//		 *Loop through the fishes array list
//		 *If a fish is alive, move the fish. Else, remove the fish from the fishes array list.
//		 */
//		for(int i = 0; i < this.fishes.size(); i++){
//			Fish f = this.fishes.get(i);
//			if(f.isAlive())
//        		f.move();
//        	else
//        		this.fishes.remove(i);
//		}
//	}
	
}
